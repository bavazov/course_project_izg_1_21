package kg.medcenters.server.service;

import kg.medcenters.server.dto.request.WhoWeAreRequest;
import kg.medcenters.server.entity.WhoWeAre;

import java.util.List;

public interface WhoWeAreService {
    WhoWeAre create(WhoWeAreRequest request);

    List<WhoWeAre> getEntity();

    WhoWeAre updateEntity(int id, WhoWeAreRequest request);

    WhoWeAre getEntityById(int id);

    void deleteById(int id);
}
