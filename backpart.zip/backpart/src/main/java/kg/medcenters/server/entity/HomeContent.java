package kg.medcenters.server.entity;

import jakarta.persistence.*;

@Entity
public class HomeContent extends CommonModel{

}
