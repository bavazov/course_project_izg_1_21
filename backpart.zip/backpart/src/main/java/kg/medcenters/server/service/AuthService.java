package kg.medcenters.server.service;

import kg.medcenters.server.dto.request.LoginRequest;
import kg.medcenters.server.dto.response.LoginResponse;

public interface AuthService {
    LoginResponse login(LoginRequest request);

}
