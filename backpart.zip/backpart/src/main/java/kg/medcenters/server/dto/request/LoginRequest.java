package kg.medcenters.server.dto.request;

public record LoginRequest(
        String username,
        String password
) {
}
