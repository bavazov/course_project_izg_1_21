package kg.medcenters.server.service;

import kg.medcenters.server.dto.request.RefreshAccessTokenRequest;
import kg.medcenters.server.dto.response.LoginResponse;
import kg.medcenters.server.entity.User;

public interface RefreshTokenService {
    String generateRefreshToken(User user);

    LoginResponse generateAccessTokenByRefreshToken(RefreshAccessTokenRequest request);
}
