package kg.medcenters.server.service.impl;

import kg.medcenters.server.dto.request.RefreshAccessTokenRequest;
import kg.medcenters.server.dto.response.LoginResponse;
import kg.medcenters.server.entity.RefreshToken;
import kg.medcenters.server.entity.User;
import kg.medcenters.server.exceptions.RefreshTokenExpiredException;
import kg.medcenters.server.exceptions.ResourceNotFound;
import kg.medcenters.server.exceptions.UserNotFoundException;
import kg.medcenters.server.jwt.JwtUtils;
import kg.medcenters.server.repo.RefreshTokenRepository;
import kg.medcenters.server.service.RefreshTokenService;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.UUID;

@Service
@FieldDefaults(level = AccessLevel.PRIVATE)
@RequiredArgsConstructor
@Slf4j
public class RefreshTokenServiceImpl implements RefreshTokenService {

    final RefreshTokenRepository refreshTokenRepository;
    final JwtUtils jwtUtils;

    @Value("${jwt_refresh_token_expiration_in_hours}")
    long jwt_refresh_token_expiration_in_hours;

    @Override
    public String generateRefreshToken(User user) {

        RefreshToken refreshToken = null;
        if (refreshTokenRepository.existsByUser(user)) {
            refreshToken = refreshTokenRepository.findByUser(user)
                    .orElseThrow(UserNotFoundException::new);
            refreshTokenRepository.delete(refreshToken);
        }
        refreshToken = generateCompleteNewRefreshToken(user);
        return refreshToken.getRefreshToken();
    }

    @Override
    public LoginResponse generateAccessTokenByRefreshToken(RefreshAccessTokenRequest request) {

        RefreshToken refreshToken = refreshTokenRepository.findByRefreshToken(request.refreshToken())
                .orElseThrow(() -> new ResourceNotFound("Refresh token not found!"));

        User user = refreshToken.getUser();


        if (isRefreshTokenExpired(refreshToken)) {
            refreshTokenRepository.delete(refreshToken);
            throw new RefreshTokenExpiredException();
        }

        refreshTokenRepository.delete(refreshToken);

        return LoginResponse.builder()
                .accessToken(jwtUtils.generate(user.getUsername()))
                .refreshToken(generateRefreshToken(user))
                .build();

    }

    private RefreshToken generateCompleteNewRefreshToken(User user) {
        return refreshTokenRepository.save(
                RefreshToken.builder()
                        .refreshToken(UUID.randomUUID().toString())
                        .user(user)
                        .expirityDate(new Date(System.currentTimeMillis() +
                                1000 * 60 * 60 * jwt_refresh_token_expiration_in_hours))
                        .build()
        );
    }


    private boolean isRefreshTokenExpired(RefreshToken refreshToken) {
        return refreshToken.getExpirityDate().before(new Date());
    }
}
