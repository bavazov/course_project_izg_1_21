package kg.medcenters.server.controller;

import io.swagger.v3.oas.annotations.security.SecurityRequirements;
import kg.medcenters.server.dto.request.WhoWeAreRequest;
import kg.medcenters.server.entity.WhoWeAre;
import kg.medcenters.server.service.WhoWeAreService;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@FieldDefaults(level = AccessLevel.PRIVATE)
@RequiredArgsConstructor
@RequestMapping("/api/who-are-lovz-kg")
public class WhoWeAreController {
    final WhoWeAreService whoWeAreService;
    @PostMapping(consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public WhoWeAre create(@ModelAttribute WhoWeAreRequest request) {
        return whoWeAreService.create(request);
    }

    @GetMapping
    @SecurityRequirements
    public List<WhoWeAre> getEntity(){
        return whoWeAreService.getEntity();
    }

    @GetMapping("/{id}")
    @SecurityRequirements
    public WhoWeAre getEntityById(@PathVariable("id") int id) {
        return whoWeAreService.getEntityById(id);
    }

    @PutMapping(value = "/{id}", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public WhoWeAre updateEntity(@PathVariable("id") int id, @ModelAttribute WhoWeAreRequest request) {
        return whoWeAreService.updateEntity(id, request);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable("id") int id) {
        whoWeAreService.deleteById(id);
    }

}
// who-are-lovz-kg