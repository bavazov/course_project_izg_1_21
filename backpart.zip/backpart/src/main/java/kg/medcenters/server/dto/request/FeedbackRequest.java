package kg.medcenters.server.dto.request;

public record FeedbackRequest(
        String name,
        String text,
        int rating
) {
}
