package kg.medcenters.server.controller;

import io.swagger.v3.oas.annotations.security.SecurityRequirements;
import kg.medcenters.server.dto.request.FeedbackRequest;
import kg.medcenters.server.dto.response.FeedbackResponse;
import kg.medcenters.server.service.FeedbackService;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.springframework.web.bind.annotation.*;

@RestController
@FieldDefaults(level = AccessLevel.PRIVATE)
@RequiredArgsConstructor
@RequestMapping("/api/feedback")
public class FeedbackController {
    final FeedbackService feedbackService;
    @PostMapping("/{clinicId}")
    @SecurityRequirements
    public FeedbackResponse create(@PathVariable("clinicId") int clinicId, @RequestBody FeedbackRequest request) {
        return feedbackService.create(clinicId,request);
    }
}
