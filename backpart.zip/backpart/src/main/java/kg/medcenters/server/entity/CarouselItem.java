package kg.medcenters.server.entity;

import jakarta.persistence.Entity;

@Entity
public class CarouselItem extends CommonModel{
}
