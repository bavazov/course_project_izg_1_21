package kg.medcenters.server.mapper;

import kg.medcenters.server.dto.response.ClinicWorkResponse;
import kg.medcenters.server.entity.ClinicWork;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface ClinicWorkMapper {
    ClinicWorkResponse toClinicWorkResponse(ClinicWork clinicWork);
}
