package kg.medcenters.server.dto.request;

public record ClinicWorkRequest(
        String name
) {
}
