package kg.medcenters.server.mapper;

import kg.medcenters.server.dto.response.ClinicResponse;
import kg.medcenters.server.entity.Clinic;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface ClinicMapper {
    ClinicResponse toClinicResponse (Clinic clinic);
}
