package kg.medcenters.server.service.impl;

import kg.medcenters.server.dto.request.LoginRequest;
import kg.medcenters.server.dto.response.LoginResponse;
import kg.medcenters.server.dto.response.UserInfo;
import kg.medcenters.server.entity.User;
import kg.medcenters.server.exceptions.UserNotFoundException;
import kg.medcenters.server.jwt.JwtUtils;
import kg.medcenters.server.mapper.UserMapper;
import kg.medcenters.server.repo.UserRepository;
import kg.medcenters.server.service.AuthService;
import kg.medcenters.server.service.RefreshTokenService;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;

@Service
@FieldDefaults(level = AccessLevel.PRIVATE)
@RequiredArgsConstructor
public class AuthServiceImpl implements AuthService {
    final AuthenticationManager authenticationManager;
    final JwtUtils jwtUtils;
    final RefreshTokenService refreshTokenService;
    final UserMapper userMapper;
    final UserRepository userRepository;

    @Override
    public LoginResponse login(LoginRequest request) {
        UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken(
                request.username(), request.password()
        );

        Authentication authentication = authenticationManager.authenticate(token);
        String accessToken = jwtUtils.generate(request.username());
        String refreshToken = refreshTokenService.generateRefreshToken((User) authentication.getPrincipal());
        UserInfo userInfo = userMapper.toUserInfo(userRepository.findByUsername(request.username()).orElseThrow(
                UserNotFoundException::new
        ));

        return LoginResponse.builder()
                .accessToken(accessToken)
                .refreshToken(refreshToken)
                .userInfo(userInfo)
                .build();
    }


}
