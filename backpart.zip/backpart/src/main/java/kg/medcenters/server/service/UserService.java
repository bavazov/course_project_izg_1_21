package kg.medcenters.server.service;

import kg.medcenters.server.dto.request.LoginRequest;
import kg.medcenters.server.dto.request.UserUpdateRequest;
import kg.medcenters.server.dto.response.UserInfo;
import kg.medcenters.server.entity.User;

import java.util.List;

public interface UserService {
    List<UserInfo> getAll();

    UserInfo getMe(User user);

    UserInfo updateMe(User user, UserUpdateRequest request);

    UserInfo register(LoginRequest request);
}
