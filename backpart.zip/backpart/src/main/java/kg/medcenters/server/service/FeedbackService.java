package kg.medcenters.server.service;

import kg.medcenters.server.dto.request.FeedbackRequest;
import kg.medcenters.server.dto.response.FeedbackResponse;

public interface FeedbackService {
    FeedbackResponse create(int clinicId, FeedbackRequest request);
}
