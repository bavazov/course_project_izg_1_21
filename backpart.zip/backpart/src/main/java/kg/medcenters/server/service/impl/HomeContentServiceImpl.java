package kg.medcenters.server.service.impl;

import kg.medcenters.server.dto.request.HomeContentRequest;
import kg.medcenters.server.entity.HomeContent;
import kg.medcenters.server.exceptions.ResourceNotFound;
import kg.medcenters.server.repo.HomeContentRepository;
import kg.medcenters.server.service.CloudinaryService;
import kg.medcenters.server.service.HomeContentService;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@FieldDefaults(level = AccessLevel.PRIVATE)
@RequiredArgsConstructor
public class HomeContentServiceImpl implements HomeContentService {
    final HomeContentRepository homeContentRepository;
    final CloudinaryService cloudinaryService;

    @Override
    public HomeContent createHomeContent(HomeContentRequest request) {
        String photoUrl = cloudinaryService.upload(request.photo());
        HomeContent homeContent = new HomeContent();
        homeContent.setHeader(request.header());
        homeContent.setText(request.text());
        homeContent.setPhotoUrl(photoUrl);
        homeContent.setPhotoAltText(request.photoAltText());
        return homeContentRepository.save(homeContent);
    }

    @Override
    public List<HomeContent> getAll() {
        return homeContentRepository.findAllByOrderByIdDesc();
    }

    @Override
    public HomeContent updateHomeContent(int homeContentId, HomeContentRequest request) {
        HomeContent updatedHomeContent = homeContentRepository.findById(homeContentId)
                .orElseThrow(() -> new ResourceNotFound("Home Content not found!"));
        if(request.photo() != null) {
            String photoUrl = cloudinaryService.upload(request.photo());
            updatedHomeContent.setPhotoUrl(photoUrl);
        }
        updatedHomeContent.setHeader(request.header());
        updatedHomeContent.setText(request.text());
        updatedHomeContent.setPhotoAltText(request.photoAltText());
        return homeContentRepository.save(updatedHomeContent);
    }

    @Override
    public HomeContent getHomeContentById(int homeContentId) {
        return homeContentRepository.findById(homeContentId).orElseThrow(
                () -> new ResourceNotFound("Home content not found!")
        );
    }

    @Override
    public void deleteById(int homeContentId) {
        homeContentRepository.deleteById(homeContentId);
    }
}
