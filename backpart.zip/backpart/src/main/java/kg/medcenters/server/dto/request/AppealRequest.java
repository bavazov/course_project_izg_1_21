package kg.medcenters.server.dto.request;

public record AppealRequest(
        String name,
        String phone,
        String text
) {
}
