package kg.medcenters.server.service.impl;

import kg.medcenters.server.dto.request.FeedbackRequest;
import kg.medcenters.server.dto.response.FeedbackResponse;
import kg.medcenters.server.entity.Clinic;
import kg.medcenters.server.entity.Feedback;
import kg.medcenters.server.exceptions.ResourceNotFound;
import kg.medcenters.server.mapper.FeedbackMapper;
import kg.medcenters.server.repo.ClinicRepository;
import kg.medcenters.server.repo.FeedbackRepository;
import kg.medcenters.server.service.FeedbackService;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.springframework.stereotype.Service;

@Service
@FieldDefaults(level = AccessLevel.PRIVATE)
@RequiredArgsConstructor
public class FeedbackServiceImpl implements FeedbackService {
    final FeedbackRepository feedbackRepository;
    final ClinicRepository clinicRepository;
    final FeedbackMapper feedbackMapper;
    @Override
    public FeedbackResponse create(int clinicId, FeedbackRequest request) {
        Clinic clinic = clinicRepository.findById(clinicId).orElseThrow(
                () -> new ResourceNotFound("Clinic not found")
        );
        Feedback feedback = new Feedback();
        feedback.setName(request.name());
        feedback.setText(request.text());
        feedback.setRating(request.rating());
        feedback.setClinic(clinic);
        return feedbackMapper.toFeedbackResponse(feedbackRepository.save(feedback));

    }
}
