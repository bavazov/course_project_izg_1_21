package kg.medcenters.server.service;

import kg.medcenters.server.dto.request.ClinicWorkRequest;
import kg.medcenters.server.dto.response.ClinicWorkResponse;

import java.util.List;

public interface ClinicWorkService {
    ClinicWorkResponse create(ClinicWorkRequest request);

    List<ClinicWorkResponse> getAll();

    ClinicWorkResponse getById(int id);

    ClinicWorkResponse updateById(int id, ClinicWorkRequest request);
}
