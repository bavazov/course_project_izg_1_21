package kg.medcenters.server.entity.enums;

public enum Roles {
    ADMIN, USER
}
