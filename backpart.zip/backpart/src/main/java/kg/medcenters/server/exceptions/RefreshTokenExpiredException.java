package kg.medcenters.server.exceptions;

public class RefreshTokenExpiredException extends RuntimeException{
    public RefreshTokenExpiredException() {
        super("Jwt Expired!");
    }
}
