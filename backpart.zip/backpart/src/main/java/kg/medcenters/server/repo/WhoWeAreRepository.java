package kg.medcenters.server.repo;

import kg.medcenters.server.entity.WhoWeAre;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface WhoWeAreRepository extends JpaRepository<WhoWeAre, Integer> {
}
