package kg.medcenters.server.service;

import kg.medcenters.server.dto.request.CarouselItemRequest;
import kg.medcenters.server.entity.CarouselItem;

import java.util.List;

public interface CarouselItemService {
    CarouselItem create(CarouselItemRequest request);

    List<CarouselItem> getAll();

    CarouselItem getById(int id);

    CarouselItem updateById(int id, CarouselItemRequest request);

    void deleteById(int id);
}
