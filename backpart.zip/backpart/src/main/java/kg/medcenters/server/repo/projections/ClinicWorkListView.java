package kg.medcenters.server.repo.projections;

public interface ClinicWorkListView {
    int getId();
    String getName();
}
