package kg.medcenters.server.service.impl;

import kg.medcenters.server.dto.request.WhoWeAreRequest;
import kg.medcenters.server.entity.WhoWeAre;
import kg.medcenters.server.exceptions.ResourceNotFound;
import kg.medcenters.server.repo.WhoWeAreRepository;
import kg.medcenters.server.service.CloudinaryService;
import kg.medcenters.server.service.WhoWeAreService;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@FieldDefaults(level = AccessLevel.PRIVATE)
@RequiredArgsConstructor
@Slf4j
public class WhoWeAreServiceImpl implements WhoWeAreService {
    final WhoWeAreRepository whoWeAreRepository;
    final CloudinaryService cloudinaryService;

    @Override
    public WhoWeAre create(WhoWeAreRequest request) {
        WhoWeAre whoWeAre = new WhoWeAre();
        whoWeAre.setHeader(request.header());
        whoWeAre.setText(request.text());
        whoWeAre.setPhotoUrl(cloudinaryService.upload(request.photo()));
        whoWeAre.setPhotoAltText(request.photoAltText());
        return whoWeAreRepository.save(whoWeAre);
    }

    @Override
    public List<WhoWeAre> getEntity() {
        return whoWeAreRepository.findAll();
    }

    @Override
    public WhoWeAre updateEntity(int id, WhoWeAreRequest request) {
        WhoWeAre updatedWhoAre = whoWeAreRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFound("Entity not found!"));
        if(request.photo() != null) {
            updatedWhoAre.setPhotoUrl(cloudinaryService.upload(request.photo()));
        }
        updatedWhoAre.setHeader(request.header());
        updatedWhoAre.setText(request.text());
        updatedWhoAre.setPhotoAltText(request.photoAltText());
        return whoWeAreRepository.save(updatedWhoAre);
    }

    @Override
    public WhoWeAre getEntityById(int id) {
        return whoWeAreRepository.findById(id).orElseThrow(
                () -> new ResourceNotFound("Entity not found!")
        );
    }

    @Override
    public void deleteById(int id) {
        whoWeAreRepository.deleteById(id);
    }
}
