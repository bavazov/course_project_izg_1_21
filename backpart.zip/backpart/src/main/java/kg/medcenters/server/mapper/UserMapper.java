package kg.medcenters.server.mapper;

import kg.medcenters.server.dto.response.UserInfo;
import kg.medcenters.server.entity.User;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface UserMapper {
    UserInfo toUserInfo(User user);
}
