package kg.medcenters.server.service;

import kg.medcenters.server.dto.request.HomeContentRequest;
import kg.medcenters.server.entity.HomeContent;

import java.util.List;

public interface HomeContentService {
    HomeContent createHomeContent(HomeContentRequest request);

    List<HomeContent> getAll();

    HomeContent updateHomeContent(int homeContentId, HomeContentRequest request);

    HomeContent getHomeContentById(int homeContentId);

    void deleteById(int homeContentId);
}
